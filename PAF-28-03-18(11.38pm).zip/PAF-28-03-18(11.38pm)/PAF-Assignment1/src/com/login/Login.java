package com.login;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Login
 */
@WebServlet("/login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//HttpServletRequest httpreq = (HttpServletRequest) request;
		//HttpServletResponse httpResp =(HttpServletResponse) response;
		PrintWriter out= response.getWriter();
		
		
		try {
		
		String uname = request.getParameter("username");
		String passwd = request.getParameter("password");
		
		
		
		String dbName= null;
		String dbPassword=null;
		
		String sql="select * from Users where Username=? and Password=?";
		Class.forName("com.mysql.jdbc.Driver");
		
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Login","root","");
		
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1,uname);
		ps.setString(2, passwd);
		ResultSet rs =ps.executeQuery();
		//PrintWriter out= response.getWriter();
		
		while(rs.next()) {
			dbName=rs.getString(1);
			dbPassword=rs.getString(2);
			
		}
		if(uname.equals(dbName)&& passwd.equals(dbPassword)) {
		
		HttpSession session = request.getSession(true);	
		RequestDispatcher req= request.getRequestDispatcher("Home.jsp");
		req.include(request, response);
		}
		
		else {
			
			out.println("<script type =\"text/javascript\">");
			out.println("alert('Invalid Login Credentials !');");
			out.println("location='Login.jsp';");
			out.println("</script>");
			//response.sendRedirect("Login.jsp");
	}
		}
		catch(ClassNotFoundException e) {
			e.printStackTrace();
			out.println(e);
			
		}
		catch(SQLException e) {
			e.printStackTrace();
			out.println(e);
		}
	}

}
